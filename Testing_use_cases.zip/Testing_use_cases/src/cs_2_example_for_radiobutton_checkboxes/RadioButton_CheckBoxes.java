package cs_2_example_for_radiobutton_checkboxes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton_CheckBoxes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*1. The user should go to "http://destinationqa.com/radiobuttons-html/"
		2. The user should select Monday Radio Button
			1. Identity the Monday radio button. 	name="groupName"
		<input name="groupName" type="radio" value="Mon">
			2. Select Monday radio button.
		3. The user should check Yellow & Orange check box
			1. Identity the Yellow and Orange check box 	name="orange"  name="yellow"
		<input name="orange" type="checkbox">
		<input checked="checked" name="yellow" type="checkbox">
			2. Check Yellow & Orange check box*/
			
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//1. The user should go to "http://destinationqa.com/radiobuttons-html/"
		driver.get("http://destinationqa.com/radiobuttons-html/");
		//2. The user should select Monday Radio Button
		List<WebElement> radioButtonList=driver.findElements(By.name("groupName"));
		for(WebElement r:radioButtonList)
		{
			String s=r.getAttribute("value");
			if(s.equalsIgnoreCase("Mon"))
			{
				r.click();
			}
		}
//		Yellow is checked by default 
		/*String check_box_item="yellow"; 
		WebElement yellow_checkbox=driver.findElement(By.name(check_box_item));
		yellow_checkbox.click();*/
		//3. The user should check Yellow & Orange check box
		String check_box_item="orange";
		WebElement orange_checkbox=driver.findElement(By.name(check_box_item));
		orange_checkbox.click();
//		Red is checked by default so it has to be unchecked
		check_box_item="red";
		WebElement red_checkbox=driver.findElement(By.name(check_box_item));
		red_checkbox.click();

	}

}
