package cs_4_example_for_getAttribute;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetAttributeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 4: // Example for getAttribute()

			1. The user should go to ebay.in "https://in.ebay.com"
			2. Get all the attribute values of the register link as per the HTML design.
			<a href="https://reg.ebay.com/reg/PartialReg?ru=https%3A%2F%2Fin.ebay.com%2F" _sp="m570.l2621" xpath="1">register</a>	*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://in.ebay.com");
		WebElement register_element=driver.findElement(By.linkText("register"));
		String href=register_element.getAttribute("href");
		System.out.println(href);
		String _sp=register_element.getAttribute("_sp");
		System.out.println(_sp);
		String xpath=register_element.getAttribute("xpath");
		System.out.println(xpath);
		driver.close();
	}

}
