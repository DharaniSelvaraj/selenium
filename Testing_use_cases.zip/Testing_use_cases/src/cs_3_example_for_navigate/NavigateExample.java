package cs_3_example_for_navigate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 3: // Example for Navigate()
			1. The user should go to "https://www.rediff.com"
			2. The user should get & print the title of the home page
			3. The user should click on Sign in link
				1. Identify the Sign in link
				2. Click on the Sign in link
			<a href="https://mail.rediff.com/cgi-bin/login.cgi" title="Already a user? Sign in" class="signin" xpath="1" style="">Sign in</a>
			4. The user should get & print the title of the Login page
			5. The user should go back to the previous page using navige method
			6. The user should get the title & check if it same as home page
			7. The user should use forward method & get the page title & check if it same as Login page
			8. The user should close all the browser entities.*/
		
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//1. The user should go to "https://www.rediff.com"
		driver.navigate().to("https://www.rediff.com");
		//2. The user should get & print the title of the home page
		String homepage_title=driver.getTitle();
		System.out.println("Title of the home page:"+homepage_title);
		//3. The user should click on Sign in link
		driver.findElement(By.linkText("Sign in")).click();
		//4. The user should get & print the title of the Login page
		String loginpage_title=driver.getTitle();
		System.out.println("Title of the login page:"+loginpage_title);
		//5. The user should go back to the previous page using navige method
		driver.navigate().back();
		//6. The user should get the title & check if it same as home page
		if(homepage_title.equals(driver.getTitle()))
		{
			System.out.println("Home page title is matched");
		}
		//7. The user should use forward method & get the page title & check if it same as Login page
		driver.navigate().forward();
		if(loginpage_title.equals(driver.getTitle()))
		{
			System.out.println("Login page title is matched");
		}
		//8. The user should close all the browser entities.
		driver.close();
	}

}
